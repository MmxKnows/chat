<?php

// Enable all errors
error_reporting(-1);

require_once(__DIR__ . '/TestCase.php');
require_once(__DIR__ . '/PAMTestCase.php');