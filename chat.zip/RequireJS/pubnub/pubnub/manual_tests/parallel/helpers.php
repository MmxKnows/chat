<?php

function puts($message) {
    print_r($message);
    echo "\n";
}