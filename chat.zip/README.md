Terminal chat testing with php with pubnub all along..
Clone this repo and run the php file