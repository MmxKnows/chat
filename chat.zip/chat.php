#!/usr/bin/php


                                           _          __  __
                                          | |         |  \/   |
                                          | |         | \  /  |
                                          | |         | |\/|  |
                                          | |_____| |   |  | 
                                          |______|_|  |_ |
                                       
                                TErMINAL ChAT Platform 
                                   



<?php

require('RequireJS/autoload.php');

//namespaces
use Pubnub\Pubnub;

//stable connection with the API
$pubnub=new Pubnub(
    'pub-c-558c5acf-75ff-497c-b31b-43c121c54bf3',
    'sub-c-357d627c-16a4-11e9-923b-9ef472141036',
    'sec-c-NzhlZDA5ZjktYWM5Ni00YjM1LWI2ODItODYyNTkwNmIyOGM0',
    false
);

//get rooms name
fwrite(STDIN, 'join room: ');
$room=trim(fgets(STDIN));

fwrite(STDOUT,"Hold on a second.. enrolling now\n");

$herenow=$pubnub->herenow($room, false, true);


//get username
function connectAs(){
    global $herenow;

    fwrite(STDOUT, "\nConnect as: ");

    $username=trim(fgets(STDIN));

    foreach($herenow['uuids'] as $user){
        if($user['state']['username']===$username){
            fwrite(STDOUT,"username taken\n");
            $username=connectAs();
        }
    }

    return $username;
};

$username=connectAs();

$pubnub->setState($room, ['username'=>$username]);


fwrite(STDOUT, "Connected to '{$room}' as '{$username}'\n");

$pid = pcntl_fork();

if($pid==-1){
    exit(1);
}elseif($pid){
    
    fwrite(STDOUT, '>');

    while(true){
        
        $message=trim(fgets(STDIN));
        $pubnub->publish($room, [

            "body" => $message,
            "username" => $username,

        ]);
    }

    pcntl_wait($status);
}else{
    $pubnub->subscribe($room, function ($payload) use ($username){
        $timestamp=date('d-m-y H:i:s');

        if($username!=$payload['message']['username']){
            fwrite(STDOUT,"\r");
        }

        fwrite(STDOUT, "[{$timestamp}] <{$payload['message']['username']}> {$payload['message']['body']}\n");
        fwrite(STDOUT, "\r>");
        return true;
    });
}


